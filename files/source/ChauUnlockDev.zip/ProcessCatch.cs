﻿using System.Diagnostics;

namespace ChauUnlock
{
    public static class libprocess
    {
        public static bool IsADBRunning()
        {
            Process[] processes = Process.GetProcessesByName("adb.exe");
            return processes.Length > 0;
        }
    }
}
