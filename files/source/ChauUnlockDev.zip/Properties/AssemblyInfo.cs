﻿using System.Resources;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
// Setup Info
[assembly: AssemblyTitle("CUnlock (Short for ChauUnlock)")]
[assembly: AssemblyDescription("One-Click ADB Done right")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ChauDev Software")]
[assembly: AssemblyProduct("ChauUnlock")]
[assembly: AssemblyCopyright("Copyright © ChauDev Software 2024")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: Guid("efc42ebc-110b-4379-815d-c03cad3ef136")]
[assembly: AssemblyVersion("1.2.0.0")]
[assembly: AssemblyFileVersion("1.2.0.0")]
[assembly: NeutralResourcesLanguage("en")]
