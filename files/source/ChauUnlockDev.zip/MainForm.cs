﻿// In this ChauUnlock v1.1
// Removed Batch File Include: Reboot, Fastboot, device All .CMD TYPE!
// Moved into Argument to Save line
// After that we move to \n to show the progress
// bruh i forget too add logcat.
// maybe c# sucks
// MANY FUCKING LINE!
// Sucks to Sucks
// ADDING SHELL!
// ADDING FUCKING STOP SERVICES
// FUCK YOU! 
// class is TOO SUCKS C# IS A NIGHTMARE.
// INSTALLER z

// in this CUnlock v1.2
// added service detection.
// VERY FUNNY.
// FIXED BUNCH OF LINE

using System;
using System.Diagnostics;
using System.Drawing;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ChauUnlock
{
    public partial class MainForm : Form
    {

        public MainForm()
        {
            InitializeComponent();
        }

    private void MainForm_Load(object sender, EventArgs e)
        {
            
        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Restart 
            Process.Start("adb.exe", "logcat");
            richTextBox1.Text = "Restarting... \nRebooting Completed\nChauUnlock v1.0 | Time: 0:05";
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            // Device 
            Process.Start("listdevice.exe", "");
        }



        private void pictureBox4_Click(object sender, EventArgs e)
        {
            // Bootloader
            Process.Start("adb.exe", "logcat");
            richTextBox1.Text = "Restarting to bootloader...\nDone Enter bootloader.\nChauUnlock v1.1 | Time: 0:05";
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            // FastBoot
            Process.Start("adb.exe", "logcat");
            richTextBox1.Text = "Restarting to fastboot...\nDone Enter Fastboot\nChauUnlock v1.1 | Time: 0:05";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Recovery
            Process.Start("adb.exe", "logcat");
            richTextBox1.Text = "Restarting to Recovery...\nDone Enter Recovery\nChauUnlock v1.1 | Time: 0:05";
        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Logcat
            Process.Start("adb.exe", "logcat");
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            // Shell
            Process.Start("adb.exe", "shell");

        }
        private void label6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure? Stop this Operation may get your device bricked or In task and Get cancel unexpected. ", "ChauUnlock - Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {                
                Process.Start("taskkill.exe", "/f /im adb.exe");
                Process.Start("taskkill.exe", "/f /im fastboot.exe");
            }
            else
            {
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to Start / Stop ADB Daemon\n*Will disconnect to Devices if Stop*\nNo: Stop | Yes: Start", "ChauUnlock - ADB Service", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                Process.Start("taskkill.exe", "/f /im adb.exe");
                Process.Start("taskkill.exe", "/f /im fastboot.exe");
                label11.Text = "Service: Not Run";
                label11.ForeColor = Color.Red;
            }
            else
            {
                StartADBProcessAsync();
            }

            async void StartADBProcessAsync()
                {
                    try
                    {
                        // Start ADB process asynchronously
                        await Task.Run(() =>
                        {
                            Process.Start("adb.exe");
                        });

                        label11.Text = "Service: Running";
                    label11.ForeColor = Color.Green;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to start ADB: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                // CLASS!hate it so musch
                }
            }

        private void label13_Click(object sender, EventArgs e)
        {
            Process.Start("https://chaudevsoftware.github.io/chaunlock/source");
        }

        private void label14_Click(object sender, EventArgs e)
        {
            // UPDATING 
            Process.Start("checkupdate.exe");
        }

        private void label15_Click(object sender, EventArgs e)
        {
            Process.Start("https://chaudevsoftware.github.io/chauunlock/video.mp4");
        }
    }
}
   
